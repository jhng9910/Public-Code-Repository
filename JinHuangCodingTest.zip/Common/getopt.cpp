#include "stdafx.h"
#include "getopt.h"
  
#include <stdio.h>
#include <string.h>

///////////////////////////////////////////////////////////////////////////////
//
//  NAME
//       getopt -- parse command line options
//
//  SYNOPSIS
//       int getopt(int argc, char *argv[], char *optstring)
//
//       extern char *optarg;
//       extern int optind;
//
//  DESCRIPTION
//       The getopt() function parses the command line arguments. Its
//       arguments argc and argv are the argument count and array as
//       passed into the application on program invocation.  In the case
//       of Visual C++ programs, argc and argv are available via the
//       variables __argc and __argv (double underscores), respectively.
//       getopt returns the next option letter in argv that matches a
//       letter in optstring.  (Note:  Unicode programs should use
//       __targv instead of __argv.  Also, all character and string
//       literals should be enclosed in _T( ) ).
//
//       optstring is a string of recognized option letters;  if a letter
//       is followed by a colon, the option is expected to have an argument
//       that may or may not be separated from it by white space.  optarg
//       is set to point to the start of the option argument on return from
//       getopt.
//
//       Option letters may be combined, e.g., "-ab" is equivalent to
//       "-a -b".  Option letters are case sensitive.
//
//       getopt places in the external variable optind the argv index
//       of the next argument to be processed.  optind is initialized
//       to 0 before the first call to getopt.
//
//       When all options have been processed (i.e., up to the first
//       non-option argument), getopt returns EOF, optarg will point
//       to the argument, and optind will be set to the argv index of
//       the argument.  If there are no non-option arguments, optarg
//       will be set to NULL.
//
//       The special option "--" may be used to delimit the end of the
//       options;  EOF will be returned, and "--" (and everything after it)
//       will be skipped.
//
//  RETURN VALUE
//       For option letters contained in the string optstring, getopt
//       will return the option letter.  getopt returns a question mark (+)
//       when it encounters an option letter not included in optstring.
//       EOF is returned when processing is finished.
//
///////////////////////////////////////////////////////////////////////////////

TCHAR *optarg;     /* global argument pointer */
TCHAR *optstr;     /* global operand pointer */
int  optind = 0;     /* global argv index */
  
int getopt(int argc, TCHAR *argv[], TCHAR *optstring)
{
    static TCHAR *next = NULL;
    TCHAR c = L'0';
	TCHAR *cp = NULL; 
	if (optind == 0)
        next = NULL;
  
	if(argc < 1 || !argv)
		return EOF;

    optarg = NULL;
	optstr = NULL;
  
   // if (next == NULL || *next == '\0')
    {
        if (optind == 0)
            optind++;
  
        if (optind >= argc)
        {
            optarg = NULL;
            if (optind < argc)
                optarg = argv[optind];
            return EOF;
        }

		if (0 == _tcscmp(argv[optind], L"--"))
        {
            optind++;
            optarg = NULL;
            if (optind < argc)
                optarg = argv[optind];
            return EOF;
        }

		if ((argv[optind][0] != L'-'  && argv[optind][0] != L'/' ) ||  argv[optind][1] == L'\0')
		{
			return L'+';
		}
    
        next = argv[optind];
        next++;     // skip past -
        optind++;
    }
  
	optstr = next;
    c = *next++;
    cp = _tcschr(optstring, c);
  
    if (cp == NULL || c == L':')
        return L'+';

    cp++;
    if (*cp == L':')
    {
        if (optind < argc)
        {
            optarg = argv[optind];
            optind++;
        }
		else if (*next != L'\0')
        {
            optarg = next;
            next = NULL;
        }
        else
        {
            return L'+';
        }
    }
	else if(!(*next == 0 || *next == L' '))
		return L'+';
  
    return c;
}

const TCHAR *getoptarg(){
	return optarg;
}

const TCHAR *getopt_str(){
	return optstr;
}

int wide_char_to_utf8(char *dest , size_t dest_length, const wchar_t *src , size_t src_length) {            
    size_t space_needed = 0 ;
    /*
        If this parameter is -1, the function processes the entire input string, including the terminating null character. 
        Therefore, the resulting Unicode string has a terminating null character, and the length returned by the function includes this character.
    */
    if(0 == (space_needed = WideCharToMultiByte(CP_UTF8, 0 , src ,  (0 == src_length) ? -1 : src_length, NULL , 0 , NULL, NULL)))
        return -1 ; //Failed to get the size 

    if(!dest)   return (0 == src_length) ? space_needed : space_needed + 1;

    return dest_length < space_needed
            ? -1
            : WideCharToMultiByte( CP_UTF8,0, src , src_length , dest ,  dest_length  , NULL, NULL) ;          
}

void  print_usage(char **usage) {
    char **pp = NULL;
    for(pp = usage; (*pp != NULL); pp++) {        
		printf("%s \n", *pp);
    }
}