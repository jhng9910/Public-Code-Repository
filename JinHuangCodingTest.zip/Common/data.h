
#include <iostream>
#include<stdio.h>
#include<stdlib.h>
#include <iomanip>
#include <fstream>
#include <string>
#include <vector>
#include <map>
#include <iterator>
#include <set>

using namespace std;

#define MAX_NB_LINE_IN_FILE 3

#define DATA_SEPERATOR "|"
#define DATA_STORE_FILE_PREFIT "f_"

#define MAX_SIZE 64
#define MAX_DATE_SIZE 10
#define MAX_REV_SIZE 16
#define MAX_TIME_SIZE 5

#define MAX_SORT_LEVEL 3

typedef enum ehn{eStb =0,eTitle=1,eProvider=2,eDate=3,eRev=4,eTime=5} eHeader;
typedef enum eact{eSelect =0,eFilter=1,eOrder=2} eAction;

class Time
{
	friend class comScore;
protected:
	int hours;
	int minutes;
	
public:
	int gethours() {return hours;};
	int getminutes() {return minutes;};

	void print(){cout << hours <<":" << minutes ;};
	int compare(Time t) 
	{
		int ret;
		if(hours != t.hours) 
			ret = hours - t.hours;
		else
		{
			if (minutes != t.minutes)
				ret = minutes - t.minutes;
			else
				ret = 0;
		}
		return ret;
	};

	void set(char * buf , int len)
	{
		char * p_m=NULL;
		char * ptch=strchr(buf,':');
				
		if(ptch != NULL && (ptch - buf + 1) < len)
		{
			p_m = ptch+1;
			*ptch ='\0';
		}
		hours = atoi(buf);
		minutes =atoi(p_m);
	};
};

class comScore
{
public:
	comScore(){ stb[0]='\0'; title[0]='\0'; provider[0]='\0'; date[0]='\0'; rev=0.0; time.hours=0; time.minutes=0;};
	~comScore(){};	

protected:
	friend class  manageLList;
	friend class linkedList;
	void print();
	int write(FILE* File);
	int read(FILE* File);
	int compare( comScore * elm, eHeader field);

public:
	char stb[MAX_SIZE+1];
	char title[MAX_SIZE+1];
	char provider[MAX_SIZE+1];
	char date[MAX_DATE_SIZE+1];
	double rev;
	Time time;
};

struct Node
{
	comScore cms; 
    struct Node* next;
};

class linkedList
{
public:
	linkedList(){};
	~linkedList(){};

	int writeNote(FILE* File, struct Node* node);
	int readNode(FILE *File, struct Node & node);

	/* Function to insert a node at the beginging of the linked list */
	void push(struct Node** head_ref, comScore * new_data);

	/* Function to insert a node at the end of the linked list */
	void push_back(struct Node** head_ref,struct Node** tail_ref, comScore * new_data);

	/* write data to a file */
	int writeData(struct Node* node,int nb_node, int nf);

	/* read data from a file */
	int readData(struct Node** head_ref, struct Node** tail_ref, int &nb_node, int nf);

	/* read all records from all db files */
	int readNodesfromDB(struct Node** head, int  nb_line_in_db);

	/* remove All nodes from memory */
	void clearupAllNodes(struct Node** node);

	/* Function to print nodes in a given linked list */
	void printList(struct Node *node);

	int writeFileInfo(int nb_of_files, int nb_of_record_in_file, long total_records, string & head_line,set<string>& keys);

	int readFileInfo(int& nb_of_files, int& nb_of_record_in_file, long& total_records, char ** head_buf,set<string>& keys);

	int readFileInfoForQuery(int& nb_of_files, int& nb_of_record_in_file, long& total_records, char ** head_buf);
};

class manageLList
{
public:
	manageLList(){setColName();};
	~manageLList(){};

	void setColName(string line);
	void setParams(string param, eAction action);
	void setSortOrder(eHeader sort_by){m_sort_by = sort_by;}
	void MergeSort(struct Node** headRef);
	
	int filterNodesInDB(struct Node** head, int  nb_line_in_db);
	int sortList(struct Node **head,int level);
	void printSelect(struct Node * node);

	vector<string> m_col_name;
	vector<int> m_order;
	vector<int> m_select;
	map<string,string> m_filter;

private:
	void setColName();
	void setOneParam(char * pch,vector<int>& vectr);
	void setKeyValue(char * col_name, char * value, eAction action);
	

	bool compare(comScore * c1, comScore * c2, eHeader field);
	struct Node* SortedMerge(struct Node* a, struct Node* b);
	void FrontBackSplit(struct Node* source, struct Node** frontRef, struct Node** backRef);
	int filterLList(struct Node **head, struct Node **tail,int &nb_node);

	void sortLList(struct Node **head, struct Node **tail, int level);
	void getNodesWithSamekeyValue(struct Node **head, struct Node **tail,int &nb_node,int level);
	
	eHeader m_sort_by;
};

/*
class hashKeys
{
public:
	hashKeys(){};
	~hashKeys(){};

	int h_stb;
	int h_title;
	int h_date;

	unsigned int hash_compute(const char *key, int len);
};
*/
