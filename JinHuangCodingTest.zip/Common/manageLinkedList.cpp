#include "stdafx.h"
#include "data.h"

#include <map>
#include <iterator>

void manageLList::setColName()
{
	m_col_name.push_back("STB");
	m_col_name.push_back("TITLE");
	m_col_name.push_back("PROVIDER");
	m_col_name.push_back("DATE");
	m_col_name.push_back("REV");
	m_col_name.push_back("VIEW_TIME");
}
void manageLList::setColName(string line)
{
  if(line.empty())
    return;
  m_col_name.clear();
  char * pch;
  
  //printf ("Splitting string \"%s\" into tokens:\n",line.c_str());
  char * str = new char [strlen(line.c_str())+1];

  if(str)
  {
	  strcpy(str,line.c_str());
	  pch = strtok (str,"|");
	  char col_nm[MAX_SIZE+1];
	  strncpy (col_nm, pch,MAX_SIZE);
	  col_nm[MAX_SIZE]='\0';
	  m_col_name.push_back(col_nm);
	
	  int nb_col =1;
	  while (pch != NULL)
	  {
		//printf ("%s\n",pch);
		pch = strtok (NULL, "|");
		if(pch == NULL)
			break;
		else
		{
			nb_col++;
			strncpy (col_nm, pch,MAX_SIZE);
			col_nm[MAX_SIZE]='\0';
			m_col_name.push_back(col_nm);
		}
	  } 
	  delete []str;
  }
}
void manageLList::setKeyValue(char * col_name, char * value, eAction action)
{
	if(eFilter) m_filter[col_name]= value;
}
void manageLList::setOneParam(char * pch, vector<int>& vectr)
{
	if((pch == m_col_name[eStb]))
		vectr.push_back(eStb);
	else if((pch == m_col_name[eTitle]))
		vectr.push_back(eTitle);
	else if((pch == m_col_name[eProvider]))
		vectr.push_back(eProvider);
	else if((pch == m_col_name[eDate]) )
		vectr.push_back(eDate);
	else if((pch == m_col_name[eRev]) )
		vectr.push_back(eRev);
	else if(pch == m_col_name[eTime])
		vectr.push_back(eTime);
	else
		cout << " error : unexpected value" << endl;
}
void manageLList::setParams(string param, eAction action)
{
  char * pch;
  string sep;
  string col_name;
  if(action == eFilter)
	  sep = "=";
  else
	  sep = ",";

  //printf ("Splitting string \"%s\" into tokens:\n",param.c_str());
  char * str = new char [strlen(param.c_str())+1];

  if(str)
  {
	  strcpy(str,param.c_str());
	  pch = strtok (str,sep.c_str());

	  if(action == eFilter)
		 col_name = pch;
	  else if(action == eOrder)
		setOneParam(pch,m_order);
	  else if(action == eSelect) 
		setOneParam(pch,m_select);

	  while (pch != NULL)
	  {
		pch = strtok (NULL, ",");
		if(pch == NULL)
			break;
		else
		{
			if(action == eFilter)
				setKeyValue((char*)col_name.c_str(),pch,eFilter);
			else if(action == eOrder)
				setOneParam(pch,m_order);
			else if(action == eSelect) 
				setOneParam(pch,m_select);
		}
	  } 
	  delete []str;
  }
}
bool  manageLList::compare(comScore * c1, comScore * c2, eHeader field)
{
	if(c1->compare(c2,field) <= 0)
		return true;
	else
		return false;
}

/* function prototypes */
/*
struct Node* SortedMerge(struct Node* a, struct Node* b);
void FrontBackSplit(struct Node* source,
        struct Node** frontRef, struct Node** backRef);
 */

/* sorts the linked list by changing next pointers (not data) */
void manageLList::MergeSort(struct Node** headRef)
{
	struct Node* head = *headRef;
	struct Node* a;
	struct Node* b;
 
	/* Base case -- length 0 or 1 */
	if ((head == NULL) || (head->next == NULL))
	{
		return;
	}
 
	/* Split head into 'a' and 'b' sublists */
	FrontBackSplit(head, &a, &b); 
 
	/* Recursively sort the sublists */
	MergeSort(&a);
	MergeSort(&b);
 
	/* answer = merge the two sorted lists together */
	*headRef = SortedMerge(a, b);
}
 
/* See https://www.geeksforgeeks.org/?p=3622 for details of this 
function */
struct Node*  manageLList::SortedMerge(struct Node* a, struct Node* b)
{
	struct Node* result = NULL;
 
	/* Base cases */
	if (a == NULL)
		return(b);
	else if (b==NULL)
		return(a);
 
	/* Pick either a or b, and recur */
	if (compare(&a->cms,&b->cms,m_sort_by))
	{
		result = a;
		result->next = SortedMerge(a->next, b);
	}
	else
	{
		result = b;
		result->next = SortedMerge(a, b->next);
	}
	return(result);
}
 
/* UTILITY FUNCTIONS */
/* Split the nodes of the given list into front and back halves,
    and return the two lists using the reference parameters.
    If the length is odd, the extra node should go in the front list.
    Uses the fast/slow pointer strategy. */
void  manageLList::FrontBackSplit(struct Node* source,
        struct Node** frontRef, struct Node** backRef)
{
    struct Node* fast;
    struct Node* slow;
    slow = source;
    fast = source->next;
 
    /* Advance 'fast' two nodes, and advance 'slow' one node */
    while (fast != NULL)
    {
    fast = fast->next;
    if (fast != NULL)
    {
        slow = slow->next;
        fast = fast->next;
    }
    }
 
    /* 'slow' is before the midpoint in the list, so split it in two
    at that point. */
    *frontRef = source;
    *backRef = slow->next;
    slow->next = NULL;
}

int manageLList::filterLList(struct Node **head, struct Node **taile,int &nb_node)
{
	struct Node *node = *head;
	struct Node * tmp= NULL;
	int nb_flitered =0;
	int nb_deleted = 0;
	int nb_total = 0;
	struct Node *filtered_head = NULL; 
	struct Node *filtered_tail = NULL;

	while(node!=NULL)
	{
		bool satisfyCondition=false; // it can be extented to several conditions
		map<string,string>::iterator p;
		for(p = m_filter.begin(); p!=m_filter.end(); ++p)   // filter map has only one element for the moment.  
		{
			//std::cout << " first (key): " << p->first << " second (value) :" << p->second  << std::endl;
					
			if((p->first == m_col_name[eStb]) && (node->cms.stb == p->second))
				satisfyCondition = true;
			else if((p->first == m_col_name[eTitle]) && (node->cms.title == p->second))
				satisfyCondition = true;
			else if((p->first == m_col_name[eProvider]) && (node->cms.provider == p->second))
				satisfyCondition = true;
			else if((p->first == m_col_name[eDate]) && (node->cms.date == p->second))
				satisfyCondition = true;
			else if((p->first == m_col_name[eRev]) && (((int)(node->cms.rev*100) -(int)(100* atof((p->second.c_str()))) ==0)))
				satisfyCondition = true;
			else if(p->first == m_col_name[eTime])
			{
				Time filter_time;
				char tmp[MAX_TIME_SIZE+1];
				strncpy(tmp,p->second.c_str(),MAX_TIME_SIZE);
				tmp[MAX_TIME_SIZE]='\0';
				filter_time.set(tmp, MAX_TIME_SIZE+1);
				if(node->cms.time.compare(filter_time)==0)
					satisfyCondition = true;
			}
			else
				satisfyCondition = false;
		}
		//cout << "  satisfyCondition = " << satisfyCondition << endl;
		if(satisfyCondition)
		{	
			if(nb_flitered ==0)
				filtered_head = node;		 // set head
			else
				filtered_tail->next =node;   // prev node point to current node

			filtered_tail = node;			
				
			node = node->next;

			nb_flitered++;
		}
		else
		{
			tmp = node->next;

			free(node);
			node = tmp;
			nb_deleted++;	
		}
		nb_total++;
	}
	if(filtered_tail != NULL)
		filtered_tail->next = NULL;
	*head = filtered_head;
	*taile = filtered_tail;
	nb_node = nb_flitered;
	//cout << " filtered = " << nb_flitered << " deleted = " << nb_deleted << " total = " << nb_total << " filtered + deleted = " << nb_flitered+ nb_deleted <<endl;
return 1;
}

int manageLList::filterNodesInDB(struct Node** head, int  nb_line_in_db)
{
	int nb_read=0;

	struct Node*  tail= NULL;
	struct Node*  tail_tmp= NULL;
	struct Node*  head_tmp= NULL;
	bool flag=false;
	linkedList ll;

	int max = nb_line_in_db%MAX_NB_LINE_IN_FILE ==0 ? nb_line_in_db/MAX_NB_LINE_IN_FILE: nb_line_in_db/MAX_NB_LINE_IN_FILE+1;

	for(int i=0; i < max; i++)
	{
		int nb_read_tmp;
		head_tmp = NULL;
		tail_tmp = NULL;
		nb_read_tmp = 0;

		if(ll.readData(&head_tmp,&tail_tmp,nb_read_tmp,i+1))
		{
			if(filterLList(&head_tmp,&tail_tmp,nb_read_tmp))
			{
				if(nb_read_tmp!=0)
				{
					if(!flag)
					{
						*head = head_tmp;
						flag = true;
					}
					else
					{
						if(tail != NULL)
							tail->next = head_tmp;
					}
					tail = tail_tmp;
					nb_read += nb_read_tmp;
				}
			}
		}
		else
			return 0;
	}
	//cout << "total number of lines in db = " << nb_line_in_db <<endl;
	//cout << "total number of filetered lines = " << nb_read <<endl;
	
	return 1;
}

void manageLList::getNodesWithSamekeyValue(struct Node **head, struct Node **tail,int &nb_node,int level)
{
	int count =0;
	struct Node * node = *head;
	struct Node * tmp_tail=NULL;
	comScore * head_cms = &(*head)->cms;
	if(node == NULL)
	{
		*tail = NULL;
		nb_node =0;
		return;
	}
	
	if(node->next ==NULL)
	{
		*head = NULL;
		*tail = node;
		nb_node = 1;

		return;
	}
	tmp_tail = node;
	node = node->next;
	nb_node++;
	while(node != NULL)
	{
		if(level ==1)
		{
			if(node->cms.compare(head_cms,(eHeader)m_order[level-1])==0)
			{
				tmp_tail = node;
				nb_node++;
				node = node->next;
			}
			else
				break;
		}
		else if(level ==2)
		{
			if((node->cms.compare(head_cms,(eHeader)m_order[level-2])==0)&&(node->cms.compare(head_cms,(eHeader)m_order[level-1])==0) )
			{
				tmp_tail = node;
				nb_node++;
				node = node->next;
			}
			else
				break;
		}
	}
	(*head) = node;
	if(tmp_tail != NULL)
		tmp_tail->next = NULL;
	*tail = tmp_tail;
}

void manageLList::sortLList(struct Node **head, struct Node **tail, int level)
{

	MergeSort(head);
	struct Node* node = *head;
	struct Node* tmp_tail = NULL;
	while(node != NULL)
	{
		tmp_tail = node;
		node = node->next;
	}
	*tail = tmp_tail;
}

int manageLList::sortList(struct Node **head,int level)
{
	int nb_total=0;

    struct Node *node = *head; 

	struct Node*  tail= NULL;
	struct Node*  tail_tmp= NULL;
	struct Node*  head_tmp= NULL;

	if(level < 1)
		return 0;

	bool flag=false;

	linkedList ll;

	while(node != NULL)
	{
		head_tmp = NULL;
		tail_tmp = NULL;
		int nb_tmp_node = 0;

		head_tmp = node;
		//setSortOrder((eHeader)m_order[level-1]);
		getNodesWithSamekeyValue(&node,&tail_tmp,nb_tmp_node,level);
		
		if(nb_tmp_node >1)
		{
			
			//printSelect(head_tmp);
			setSortOrder((eHeader)m_order[level]);
			sortLList(&head_tmp, &tail_tmp, level);
			//printSelect(head_tmp);
		}

		if(nb_tmp_node!=0)
		{
			if(!flag)
			{
				*head = head_tmp;
				flag = true;
			}
			else
			{
				if(tail != NULL)
					tail->next = head_tmp;
			}
			tail = tail_tmp;
			
		}
		nb_total += nb_tmp_node;
		//cout << "nb_tmp_node = " << nb_tmp_node <<endl;
	}
	//cout << "nb_total = " << nb_total <<endl;
	
	return 1;
}

void manageLList::printSelect(struct Node * node)
{
	int nb = 1;
	while(node!=NULL)
	{
		cout << " printSelect node : " << nb << "\t" ;
		int max = m_select.size();
		string output;
		for(int i=0; i < max; i++)
		{
			char tmp_str[MAX_REV_SIZE+1];
			if(m_select[i] == eStb)		output += " "+ string(node->cms.stb) + "\t"; 
			else if(m_select[i] == eTitle)		output += " "+ string(node->cms.title) + "\t";
			else if(m_select[i] == eProvider)	output += " "+ string(node->cms.provider) + "\t";
			else if(m_select[i] == eDate)	output += " "+ string(node->cms.date) + "\t";			
			else if(m_select[i] == eRev)	{
				sprintf(tmp_str,"%.2f",node->cms.rev);
				output += " "+ string(tmp_str) + "\t";
			}
			else if(m_select[i] == eTime)	{
				sprintf(tmp_str,"%d:%02d",node->cms.time.gethours(),node->cms.time.getminutes());
				output += " "+ string(tmp_str) + "\t";
			}
		}

		cout << output << endl;
		node = node->next;	
		nb++;
	}
}