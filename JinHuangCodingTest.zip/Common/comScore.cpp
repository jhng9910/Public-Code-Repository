#include "stdafx.h"
#include "data.h"
#include <iostream>
#include <iomanip>
#include <fstream>
#include <string>
using namespace std;

void comScore::print()
{
		char time_str[MAX_TIME_SIZE+1];
		sprintf(time_str,"%2d:%02d",time.hours,time.minutes);
		char rev_str[MAX_REV_SIZE+1];
		sprintf(rev_str,"%.2f",rev);
		cout << "comScore:  " <<  stb <<"\t" <<  title << "\t" << provider << "\t" <<  date << "\t" << rev_str << "\t" << time_str << endl;
}
int comScore::write(FILE* File)
{
	int len = strlen(stb);
	fwrite((char *)&len,sizeof(int),1,File);
	fwrite((char *)stb,strlen(stb),1,File);

	len = strlen(title);
	fwrite((char *)&len,sizeof(int),1,File);
	fwrite((char *)title,strlen(title),1,File);

	len = strlen(provider);
	fwrite((char *)&len,sizeof(int),1,File);
	fwrite((char *)provider,strlen(provider),1,File);

	len = strlen(date);
	fwrite((char *)&len,sizeof(int),1,File);
	fwrite((char *)date,strlen(date),1,File);

	fwrite((char *)&rev,sizeof(double),1,File);

	fwrite((char *)&time.hours,sizeof(int),1,File);
	fwrite((char *)&time.minutes,sizeof(int),1,File);
	return 1;
}

int comScore::read(FILE *File)
{
	int len =0;
	fread((char *)&len,sizeof(int),1,File);
	fread((char *)stb,len,1,File);
	stb[len]='\0';
	
	fread((char *)&len,sizeof(int),1,File);
	fread((char *)title,len,1,File);
	title[len]='\0';

	fread((char *)&len,sizeof(int),1,File);
	fread((char *)provider,len,1,File);
	provider[len]='\0';
	
	fread((char *)&len,sizeof(int),1,File);
	fread((char *)date,len,1,File);
	date[len]='\0';
	
	fread((char *)&rev,sizeof(double),1,File);

	fread((char *)&time.hours,sizeof(int),1,File);
	fread((char *)&time.minutes,sizeof(int),1,File);
	
	//print();
	return 1;
}
int comScore::compare( comScore * elm, eHeader field)
{
	int ret;
	if(elm == this)
		return 0;
	int v1, v2;
	switch(field)
	{
	case eStb:
		ret = strcmp(stb,elm->stb);
		break;
	case eTitle:
		ret = strcmp(title,elm->title);
		break;
	case eProvider:
		ret = strcmp(provider,elm->provider);
		break;
	case eDate:
		ret = strcmp(date,elm->date);
		break;
	case eRev:
		v1 = (int)(rev * 100);
		v2 = (int)(elm->rev *100);
		ret = v1 - v2;
		break;
	case eTime:
		ret=time.compare(elm->time);
		break;

	default:
		ret=0;
		cout << "error: param for sorting is wrong " << endl; 
	}
	return ret;
}

/*
unsigned int hashKeys::hash_compute(const char *key, int len) {
    if(key) {
        unsigned char *p = (unsigned char*)key;
        unsigned int h = 0;
        int i;

        for (i = 0; i < len; i++)
            h = 33 * h ^ p[i];

        return h;
    }
    return 0;
}
*/