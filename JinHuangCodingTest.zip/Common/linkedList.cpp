#include "stdafx.h"
#include "data.h"
#include <iostream>
#include <iomanip>
#include <fstream>
#include <string>
using namespace std;

extern char output_dir[MAX_PATH];

int linkedList::writeNote(FILE* File, struct Node* node)
{
	if(node != NULL )
	{
		//node->cms.print();
		node->cms.write(File);
	}
	return 1;
}

int linkedList::readNode(FILE *File, struct Node & node)
{
	node.cms.read(File);
	//node.cms.print();
	return 1;
}

/* Function to insert a node at the beginging of the linked list */
void linkedList::push(struct Node** head_ref, comScore * new_data)
{
	/* allocate node */
	struct Node* new_node =
            (struct Node*) malloc(sizeof(struct Node));
 
	/* put in the data */
	//new_node->data = new_data;
	memcpy(&new_node->cms,new_data,sizeof(comScore));
 
	/* link the old list off the new node */
	new_node->next = (*head_ref); 
 
	/* move the head to point to the new node */
	(*head_ref) = new_node;
} 

/* Function to insert a node at the end of the linked list */
void linkedList::push_back(struct Node** head_ref,struct Node** tail_ref, comScore * new_data)
{
	/* allocate node */
	struct Node* new_node =
            (struct Node*) malloc(sizeof(struct Node));
 
	/* put in the data */
	//new_node->data = new_data;
	memcpy(&new_node->cms,new_data,sizeof(comScore));

	new_node->next = NULL;

	if( *tail_ref == NULL)
		(*head_ref) = new_node;
	else
	{
		/* link the old list off the new node */
		(*tail_ref)->next = new_node;
		
	}
	/* move the tail_ref to point to the new node */
    (*tail_ref) = new_node;
} 

int linkedList::writeData(struct Node* node,int nb_node, int nf)
{
	char file_name[MAX_PATH];
	sprintf_s(file_name,"%s\\%s%d",output_dir,DATA_STORE_FILE_PREFIT,nf);
	int count=0;
    FILE *File = fopen(file_name,"wb");	
	if(File != NULL)
	{   
		fwrite((char *)&nb_node,sizeof(int),1,File);
		//cout << endl << " write nb_node " << nb_node << " from  " << file_name << endl;
		while(node!=NULL && count < nb_node)
		{
			writeNote(File, node);
			node = node->next;
			count++;
		}
		fclose(File);
	}
	else 
		return 0;
	return 1;
}

int linkedList::readData(struct Node** head_ref, struct Node** tail_ref, int &nb_node, int nf)
{
	char file_name[MAX_PATH];
	
	sprintf_s(file_name,"%s\\%s%d",output_dir,DATA_STORE_FILE_PREFIT,nf);
	
    FILE *File = fopen(file_name,"rb");
	if(File != NULL)
	{
		fread((char *)&nb_node,sizeof(nb_node),1,File); 
		//cout << " read nb_node " << nb_node << " from "  <<  file_name << endl;
		for(int i=0; i < nb_node; i++)
		{  
			Node node;
			readNode(File, node);
			push_back(head_ref,tail_ref,&node.cms);
		}
		fclose(File);
	}
	else
		return 0;
	return 1;
}
int linkedList::readNodesfromDB(struct Node** head, int  nb_line_in_db)
{
	int nb_read=0;

	struct Node*  tail= NULL;
	struct Node*  tail_tmp= NULL;
	struct Node*  head_tmp= NULL;

	int max = nb_line_in_db%MAX_NB_LINE_IN_FILE ==0 ? nb_line_in_db/MAX_NB_LINE_IN_FILE: nb_line_in_db/MAX_NB_LINE_IN_FILE+1;

	for(int i=0; i < max; i++)
	{
		int nb_read_tmp;
		head_tmp = NULL;
		tail_tmp = NULL;
		nb_read_tmp = 0;
		if(readData(&head_tmp,&tail_tmp,nb_read_tmp,i+1))
		{

			if(i==0)
				*head = head_tmp;
			else
			{
				tail->next = head_tmp;
			}
			tail = tail_tmp;
			nb_read += nb_read_tmp;
		}
	}
	//cout << "total number of lines read from files = " << nb_read <<endl;
	//cout << "total number of lines in db = " << nb_line_in_db <<endl;
	if(nb_read != nb_line_in_db)
		return 0;
	return 1;
}
void linkedList::clearupAllNodes(struct Node** node)
{
	Node * head = *node;
	Node * tmp = NULL;
	while(head != NULL)
	{
		tmp = head->next;
		head->next = NULL;
		free(head);
		head = tmp;
	}
	(*node)=NULL;
}

/* Function to print nodes in a given linked list */
void linkedList::printList(struct Node *node)
{
	int nb = 1;
	
	while(node!=NULL)
	{
		cout << "print node :" << nb << "\t" ;
		node->cms.print();
		node = node->next;	
		nb++;
	}
}
 
int linkedList::writeFileInfo(int nb_of_files, int nb_of_record_in_file,long total_records, string & head_line,set<string>& keys)
{
	char file_name[MAX_PATH];
	linkedList ll;
	sprintf_s(file_name,"%s\\%s%s",output_dir,DATA_STORE_FILE_PREFIT,"Info");
    FILE *File = fopen(file_name,"wb");	
	
	if(File != NULL)
	{   
		char end_of_line='\n';
		fwrite((char *)&nb_of_files,sizeof(int),1,File);
		//cout << " write nb_of_files " << nb_of_files << endl;

		fwrite((char *)&nb_of_record_in_file,sizeof(int),1,File);
		//cout << " nb_of_record_in_file " << nb_of_record_in_file << endl;

		fwrite((char *)&total_records,sizeof(long),1,File);
		//cout << " total_records " << total_records << endl;

		int len = head_line.size();
		fwrite((char *)&len,sizeof(int),1,File);
		fwrite((char *)head_line.c_str(),len,1,File);
		//cout << " head_line " << head_line << endl;

		long keys_size= keys.size();
		fwrite((char *)&keys_size,sizeof(long),1,File);
		std::set<string>::iterator it;
		for (it=keys.begin(); it!=keys.end(); ++it)
		{
			len =(*it).length();
			fwrite((char *)&len,sizeof(int),1,File);
			fwrite((char *)(*it).c_str(),len,1,File);
		}
		//cout << " keys.size() " << keys.size() << endl;

		fclose(File);
	}
	else
		return 0;
	return 1;
}
int linkedList::readFileInfoForQuery(int& nb_of_files, int& nb_of_record_in_file, long& total_records, char ** head_buf)
{
	char file_name[MAX_PATH];
	sprintf_s(file_name,"%s\\%s%s",output_dir,DATA_STORE_FILE_PREFIT,"Info");
    FILE *File = fopen(file_name,"rb");	
	
	if(File == NULL)   
		return 0;
	else
	{
		char end_of_line='\n';
		fread((char *)&nb_of_files,sizeof(int),1,File);
		//cout << " write nb_of_files " << nb_of_files << endl;

		fread((char *)&nb_of_record_in_file,sizeof(int),1,File);
		//cout << " nb_of_record_in_file " << nb_of_record_in_file << endl;

		fread((char *)&total_records,sizeof(long),1,File);
		//cout << " total_records " << total_records << endl;

		int len =0;
		fread((char *)&len,sizeof(int),1,File);
		fread((char *)(*head_buf),len,1,File);
		(*head_buf)[len]='\0';
		//cout << " heads " << (*head_buf) << endl;

		fclose(File);
	}
	return 1;
}
int linkedList::readFileInfo(int& nb_of_files, int& nb_of_record_in_file, long& total_records, char ** head_buf,set<string>& keys)
{
	char file_name[MAX_PATH];
	sprintf_s(file_name,"%s\\%s%s",output_dir,DATA_STORE_FILE_PREFIT,"Info");
    FILE *File = fopen(file_name,"rb");	
	
	if(File == NULL)   
		return 0;
	else
	{
		char end_of_line='\n';
		fread((char *)&nb_of_files,sizeof(int),1,File);
		//cout << " write nb_of_files " << nb_of_files << endl;

		fread((char *)&nb_of_record_in_file,sizeof(int),1,File);
		//cout << " nb_of_record_in_file " << nb_of_record_in_file << endl;

		fread((char *)&total_records,sizeof(long),1,File);
		//cout << " total_records " << total_records << endl;

		int len =0;
		fread((char *)&len,sizeof(int),1,File);
		fread((char *)(*head_buf),len,1,File);
		(*head_buf)[len]='\0';
		//cout << " heads " << (*head_buf) << endl;

		long keys_size;
		fread((char *)&keys_size,sizeof(long),1,File);
		for(long i=0 ; i < keys_size ; i++)
		{
			fread((char *)&len,sizeof(int),1,File);
			char * pkey = new char[len+1];
			fread((char *)pkey,len,1,File);
			pkey[len]='\0';
			keys.insert(string(pkey));
			delete []pkey;
		}
		//cout << " keys.size() " << keys.size() << endl;

		fclose(File);
	}
	return 1;
}
