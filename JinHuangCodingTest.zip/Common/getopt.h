#ifndef GETOPT_H_INCLUDED
#define GETOPT_H_INCLUDED

extern "C" {

int getopt(int argc, TCHAR *argv[], TCHAR *optstring);

const TCHAR *getoptarg();

const TCHAR *getopt_str();

int wide_char_to_utf8(char *dest , size_t dest_length, const wchar_t *src , size_t src_length) ;

bool validate_params(const TCHAR *data_path, const TCHAR *output_path);

void  print_usage(char **usage);

}
#endif /*GETOPT_H_INCLUDED*/
 
