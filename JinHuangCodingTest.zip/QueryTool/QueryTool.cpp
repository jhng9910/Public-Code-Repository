// QueryTool.cpp : Defines the entry point for the console application.
//
#include "stdafx.h"
#include "getopt.h"
#include "data.h"

char output_dir[MAX_PATH];

static char *tool_usage[] = {
	"\nUsage : query -s <items> -f <filter> -o <order by> -d <db path> \n",
    "   e.g.  \n",
	"   query -s TITLE,REV,DATE,STB -f DATE=2014-04-01 -o TITLE,STB -d ..\\dataStore \n",
	NULL
};

bool validate_params(const TCHAR *db_path){
	if(db_path && (_tcslen(db_path) > 0)) {	
		return true;
	}
	return false;
}
// return 1 when fail
int _tmain(int argc, _TCHAR* argv[])
{
	char header[MAX_PATH];
	char * pheader=header;
	ifstream read;
	long nb_line_in_db=0;
	int nb_of_files =0;
	int nb_of_record_in_file = MAX_NB_LINE_IN_FILE;

	manageLList ml;

	//////////////////////// get options ///////////////
	const TCHAR *data_path = NULL;
	const TCHAR *db_path = NULL;
	const TCHAR *order_items = NULL;
	const TCHAR *filter_items = NULL;
	const TCHAR *selected_items = NULL;
	char param_items[MAX_PATH+1];
	int ch;

	    if(argc < 3) {
        print_usage(tool_usage); 
        return 1;
    }   

	while ((ch = getopt(argc, argv, L"s:f:o:d:")) != EOF){
        switch (ch){            
			case L's':
				selected_items = getoptarg();   
                break;
			case L'f':
				filter_items = getoptarg();                
                break;
			case L'o':
				order_items = getoptarg();                
                break;
			case L'd':
				db_path = getoptarg();                
                break;
            default:
                printf("\n Error: Inalid option supplied \n \n");
				print_usage(tool_usage); 
                return 1;
                break;
        }
    }
	
	if(!validate_params(db_path)){
		fprintf(stderr, "Invalid parameters passed");
		print_usage(tool_usage); 
        return 1;
	}

	int str_len=0;
	if(db_path &&_tcslen(db_path))
	{
		str_len=wide_char_to_utf8(output_dir , MAX_PATH-1, db_path , _tcslen(db_path));
		if(str_len >=0) output_dir[str_len]='\0';
	}

	if(selected_items && _tcslen(selected_items))
	{
		str_len=wide_char_to_utf8(param_items , MAX_PATH-1, selected_items , _tcslen(selected_items));
		if(str_len >=0) param_items[str_len]='\0';
		ml.setParams(param_items, eSelect);
	}

	if(order_items && _tcslen(order_items))
	{
		str_len=wide_char_to_utf8(param_items , MAX_PATH-1, order_items , _tcslen(order_items));
		if(str_len >=0) param_items[str_len]='\0';
		ml.setParams(string(param_items),eOrder);
	}

	if(filter_items && _tcslen(filter_items))
	{
		str_len=wide_char_to_utf8(param_items , MAX_PATH-1, filter_items , _tcslen(filter_items));
		if(str_len >=0) param_items[str_len]='\0';
		ml.setParams(string(param_items),eFilter);
	}

	
    // initialization with data in f_info if it exist 
	linkedList ll;
	int ret =ll.readFileInfoForQuery(nb_of_files, nb_of_record_in_file,nb_line_in_db, &pheader );
	if(ret ==0)
	{
		fprintf(stderr, "Invalid Info file");
		print_usage(tool_usage); 
        return 1;
	}
	ml.setColName(pheader);

	/////////// test /////////////////////
	cout << "Get all nodes from db" << endl;
	struct Node*  head= NULL;
	ll.readNodesfromDB(&head,nb_line_in_db);
	cout << "\t\theader \t\t" << pheader << endl;
	ll.printList(head);
	ll.clearupAllNodes(&head);

	//////// apply filter first //////////////
	struct Node *total_filtered_head = NULL; 
	struct Node *total_filtered_tail = NULL;
	int  nb_total_line_in_db=nb_line_in_db;
	if(ml.m_filter.size() > 0)
		ml.filterNodesInDB(&total_filtered_head, nb_total_line_in_db);
	else
		ll.readNodesfromDB(&total_filtered_head,nb_line_in_db);
	
	printf("\n\tafter apply filter (if any): \n");
	ml.printSelect(total_filtered_head);

	//first level sort
	if(ml.m_order.size()> 0)
	{
		ml.setSortOrder((eHeader)ml.m_order[0]);
		ml.MergeSort(&total_filtered_head);
		printf("\n\tafter 1st sort Linked List is: \n");
		ml.printSelect(total_filtered_head);
	}

	// Now it supports only 3 level ordering, it can be easily extended to more by modifying manageLList::getNodesWithSamekeyValue
	int max_level= ml.m_order.size() < MAX_SORT_LEVEL ? ml.m_order.size():MAX_SORT_LEVEL;
	  
	// from the 2nd level sort
	for(int i=1; i < max_level; i++)
	{
		if(ml.m_order.size()> i)
		{
			ml.setSortOrder((eHeader)ml.m_order[i]);
			ml.sortList(&total_filtered_head,i);
			printf("\n\tafter %d sort Linked List: \n",i+1);
			ml.printSelect(total_filtered_head);
		}
	}
	ll.clearupAllNodes(&total_filtered_head);

	//getchar();
	return 0;
}

