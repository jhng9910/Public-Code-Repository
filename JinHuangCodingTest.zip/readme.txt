C:\Jin\learning\C_C_plus\ComScore\Coding_test\Debug>import

Usage : import -i <input data name with path> -o <output db path>

   e.g.

   import -i ..\data\test.txt -o ..\dataStore
-------------------------------------------------------------
C:\Jin\learning\C_C_plus\ComScore\Coding_test\Debug>import -i ..\data\test_1.txt -o ..\datastore
nb_line_input = 6         nb_line_in_db = 5      keys.size = 5

Get all nodes from db
                header          STB|TITLE|PROVIDER|DATE|REV|VIEW_TIME
print node :1   comScore:  stb2 the hobbit      warner bros     2014-04-02      8.00     2:45
print node :2   comScore:  stb1 unbreakable     buena vista     2014-04-03      6.00     2:05
print node :3   comScore:  stb1 the matrix      warner bros     2014-04-01      4.00     1:30
print node :4   comScore:  stb1 a matrix        warner bros     2014-04-01      4.00     1:30
print node :5   comScore:  stb3 the matrix      warner bros     2014-04-02      4.00     1:05
--------------------------------------------------------------
C:\Jin\learning\C_C_plus\ComScore\Coding_test\Debug>import -i ..\data\test_2.txt -o ..\datastore
nb_line_input = 6         nb_line_in_db = 10     keys.size = 10

Get all nodes from db
                header          STB|TITLE|PROVIDER|DATE|REV|VIEW_TIME
print node :1   comScore:  stb2 the hobbit      warner bros     2014-04-02      8.00     2:45
print node :2   comScore:  stb1 unbreakable     buena vista     2014-04-03      6.00     2:05
print node :3   comScore:  stb1 the matrix      warner bros     2014-04-01      4.00     1:30
print node :4   comScore:  stb4 the matrix      warner bros     2014-04-01      4.00     1:30
print node :5   comScore:  stb1 a matrix        warner bros     2014-04-01      4.00     1:30
print node :6   comScore:  stb3 the matrix      warner bros     2014-04-02      4.00     1:05
print node :7   comScore:  stb6 the matrix      warner bros     2014-04-02      4.00     1:05
print node :8   comScore:  stb6 unbreakable     buena vista     2014-04-03      6.00     2:05
print node :9   comScore:  stb5 the matrix      warner bros     2014-04-01      4.00     1:30
print node :10  comScore:  stb7 a matrix        warner bros     2014-04-01      4.00     1:30

---------------------------------------------------------------
C:\Jin\learning\C_C_plus\ComScore\Coding_test\Debug>import -i ..\data\test_3.txt -o ..\datastore
nb_line_input = 2         nb_line_in_db = 11     keys.size = 11

Get all nodes from db
                header          STB|TITLE|PROVIDER|DATE|REV|VIEW_TIME
print node :1   comScore:  stb2 the hobbit      warner bros     2014-04-02      8.00     2:45
print node :2   comScore:  stb1 unbreakable     buena vista     2014-04-03      6.00     2:05
print node :3   comScore:  stb1 the matrix      warner bros     2014-04-01      4.00     1:30
print node :4   comScore:  stb4 the matrix      warner bros     2014-04-01      4.00     1:30
print node :5   comScore:  stb1 a matrix        warner bros     2014-04-01      4.00     1:30
print node :6   comScore:  stb3 the matrix      warner bros     2014-04-02      4.00     1:05
print node :7   comScore:  stb6 the matrix      warner bros     2014-04-02      4.00     1:05
print node :8   comScore:  stb6 unbreakable     buena vista     2014-04-03      6.00     2:05
print node :9   comScore:  stb5 the matrix      warner bros     2014-04-01      4.00     1:30
print node :10  comScore:  stb8 the matrix      a warner bros   2014-04-01      4.00     1:30
print node :11  comScore:  stb7 a matrix        warner bros     2014-04-01      4.00     1:30

---------------------------------------------------------------------------------
note:  number of files =4 ,  max number of records in a file=3
===============================================

C:\Jin\learning\C_C_plus\ComScore\Coding_test\Debug>query

Usage : query -s <items> -f <filter> -o <order by> -d <db path>

   e.g.

   query -s TITLE,REV,DATE,STB -f DATE=2014-04-01 -o TITLE,STB -d ..\dataStore
------------------------------------------------------------

C:\Jin\learning\C_C_plus\ComScore\Coding_test\Debug>query -s TITLE,REV,DATE,STB -f DATE=2014-04-01 -o TITLE,STB -d ..\datastore
load all nodes to Linked List :
print node :1   comScore:  stb2 the hobbit      warner bros     2014-04-02      8.00     2:45
print node :2   comScore:  stb1 unbreakable     buena vista     2014-04-03      6.00     2:05
print node :3   comScore:  stb1 the matrix      warner bros     2014-04-01      4.00     1:30
print node :4   comScore:  stb4 the matrix      warner bros     2014-04-01      4.00     1:30
print node :5   comScore:  stb1 a matrix        warner bros     2014-04-01      4.00     1:30
print node :6   comScore:  stb3 the matrix      warner bros     2014-04-02      4.00     1:05
print node :7   comScore:  stb6 the matrix      warner bros     2014-04-02      4.00     1:05
print node :8   comScore:  stb6 unbreakable     buena vista     2014-04-03      6.00     2:05
print node :9   comScore:  stb5 the matrix      warner bros     2014-04-01      4.00     1:30
print node :10  comScore:  stb8 the matrix      a warner bros   2014-04-01      4.00     1:30
print node :11  comScore:  stb7 a matrix        warner bros     2014-04-01      4.00     1:30

        after apply filter:
 printSelect node : 1    the matrix      4.00    2014-04-01      stb1
 printSelect node : 2    the matrix      4.00    2014-04-01      stb4
 printSelect node : 3    a matrix        4.00    2014-04-01      stb1
 printSelect node : 4    the matrix      4.00    2014-04-01      stb5
 printSelect node : 5    the matrix      4.00    2014-04-01      stb8
 printSelect node : 6    a matrix        4.00    2014-04-01      stb7

        after 1st sort Linked List is:
 printSelect node : 1    a matrix        4.00    2014-04-01      stb1
 printSelect node : 2    a matrix        4.00    2014-04-01      stb7
 printSelect node : 3    the matrix      4.00    2014-04-01      stb1
 printSelect node : 4    the matrix      4.00    2014-04-01      stb4
 printSelect node : 5    the matrix      4.00    2014-04-01      stb5
 printSelect node : 6    the matrix      4.00    2014-04-01      stb8

        after 2nd sort Linked List is:
 printSelect node : 1    a matrix        4.00    2014-04-01      stb1
 printSelect node : 2    a matrix        4.00    2014-04-01      stb7
 printSelect node : 3    the matrix      4.00    2014-04-01      stb1
 printSelect node : 4    the matrix      4.00    2014-04-01      stb4
 printSelect node : 5    the matrix      4.00    2014-04-01      stb5
 printSelect node : 6    the matrix      4.00    2014-04-01      stb8
------------------------------------------------------------

Here are three test files contents

..\data\test_1.txt
STB|TITLE|PROVIDER|DATE|REV|VIEW_TIME 
stb1|the matrix|warner bros|2014-04-01|4.00|1:30 
stb1|the matrix|warner bros|2014-04-01|4.00|1:30 
stb1|unbreakable|buena vista|2014-04-03|6.00|2:05 
stb2|the hobbit|warner bros|2014-04-02|8.00|2:45 
stb3|the matrix|warner bros|2014-04-02|4.00|1:05 
stb1|a matrix|warner bros|2014-04-01|4.00|1:30 

..\data\test_2.txt 
STB|TITLE|PROVIDER|DATE|REV|VIEW_TIME 
stb4|the matrix|warner bros|2014-04-01|4.00|1:30 
stb5|the matrix|warner bros|2014-04-01|4.00|1:30 
stb6|unbreakable|buena vista|2014-04-03|6.00|2:05 
stb2|the hobbit|warner bros|2014-04-02|8.00|2:45 
stb6|the matrix|warner bros|2014-04-02|4.00|1:05 
stb7|a matrix|warner bros|2014-04-01|4.00|1:30 

..\data\test_3.txt  
STB|TITLE|PROVIDER|DATE|REV|VIEW_TIME 
stb8|the matrix|a warner bros|2014-04-01|4.00|1:30 