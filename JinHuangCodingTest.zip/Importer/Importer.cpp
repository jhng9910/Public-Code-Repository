// Coding_test.cpp : Defines the entry point for the console application.
//
#include "stdafx.h"
#include <iostream>
#include <iomanip>
#include <fstream>
#include <string>
using namespace std;

#include<stdio.h>
#include<stdlib.h>

#include <map>
#include <iterator>

#include "data.h"
#include "getopt.h"

char output_dir[MAX_PATH];

bool should_add(set<string> &keys, string& node_key)
{
	set<string>::iterator it = keys.find(node_key);
	if( it != keys.end())
		return false;  //found
	else
		return true;
}
void parse(string& line,struct Node& node)
{
  char * pch;
  //printf ("Splitting string \"%s\" into tokens:\n",line.c_str());
  char * str = new char [strlen(line.c_str())+1];

  if(str)
  {
	  strcpy(str,line.c_str());
	  pch = strtok (str,DATA_SEPERATOR);

	  strncpy (node.cms.stb, pch,MAX_SIZE);
	  node.cms.stb[MAX_SIZE]='\0';
	
	  int nb_col =1;
	  while (pch != NULL)
	  {
		//printf ("%s\n",pch);
		pch = strtok (NULL, DATA_SEPERATOR);
		if(pch == NULL)
			break;
		else
		{
			nb_col++;
			switch(nb_col)
			{
			
			case 2: 
				strncpy (node.cms.title, pch,MAX_SIZE);
				node.cms.title[MAX_SIZE]='\0';
				break;
			case 3: 
				strncpy (node.cms.provider, pch,MAX_SIZE);
				node.cms.provider[MAX_SIZE]='\0';
				break;
			case 4: 
				strncpy (node.cms.date, pch,MAX_DATE_SIZE);
				node.cms.date[MAX_DATE_SIZE]='\0';
				break;
			case 5: 
				node.cms.rev = atof(pch);
				break;
			case 6: 
				char tmp[MAX_TIME_SIZE+1];
				strncpy (tmp, pch,MAX_TIME_SIZE);
				tmp[MAX_TIME_SIZE]='\0';
				node.cms.time.set(tmp,MAX_TIME_SIZE+1);
				break;
			default:
				cout << " unexpected data format" << endl;
			}
		}
	  } 
	  delete []str;
  }
}
void process(struct Node** list,set<string>&keys, string& line, long& nb_line) {
    //cout << "line read: " << line  << endl;
	linkedList ll;
	struct Node current_node;
	parse(line, current_node );
	string aKey= string(current_node.cms.date) + "\t" + string(current_node.cms.title) + "\t" + string(current_node.cms.stb);
	//if(should_add(*list, &current_node, nb_line))
	if(should_add(keys,aKey))
	{
		if((nb_line >= MAX_NB_LINE_IN_FILE) && (nb_line % MAX_NB_LINE_IN_FILE ==0) )
		{
			if(ll.writeData((*list),MAX_NB_LINE_IN_FILE, nb_line/MAX_NB_LINE_IN_FILE))
			{
				ll.clearupAllNodes(list);
			}
		}
		ll.push(list, &current_node.cms);
		keys.insert(aKey);
		nb_line++;
	}
}

bool validate_params(const TCHAR *data_path, const TCHAR *output_path){
	if(data_path && (_tcslen(data_path) > 0) && 
       output_path && (_tcslen(output_path) > 0)) {	
		return true;
	}
	return false;
}
static char *tool_usage[] = {
	"\nUsage : import -i <input data name with path> -o <output db path> \n",
    "   e.g.  \n",
	"   import -i ..\\data\\test.txt -o ..\\dataStore \n",
	NULL
};

// return 1 when failed
int _tmain(int argc, TCHAR* argv[])
{
	struct Node* h_llist = NULL;
	struct Node* llist = NULL;
	set<string> keys;
	char file_name[MAX_PATH];
	char header[MAX_PATH];
	char * pheader=header;
	ifstream read;
	string line;
	string header_line;
	long nb_line_input=0;
	long nb_line_in_db=0;
	int nb_of_files =0;
	int nb_of_record_in_file = MAX_NB_LINE_IN_FILE;

	//////////////////////// get options ///////////////
	const TCHAR *data_path = NULL;
	const TCHAR *output_path = NULL;

	int ch;
	    if(argc < 5) {
        print_usage(tool_usage); 
        return 1;
    }   

	while ((ch = getopt(argc, argv, L"i:o:")) != EOF){
        switch (ch){            
			case L'i':
				data_path = getoptarg();                
                break;
			case L'o':
				output_path = getoptarg();                
                break;
            default:
                printf("\n Error: Inalid option supplied \n \n");
				print_usage(tool_usage); 
                return 1;
                break;
        }
    }
	
	if(!validate_params(data_path, output_path)){
		fprintf(stderr, "Invalid parameters passed");
		print_usage(tool_usage); 
        return 1;
	}

	int len;
	if(data_path != NULL && _tcslen(data_path))
	{
		len=wide_char_to_utf8(file_name , MAX_PATH-1, data_path , _tcslen(data_path));
		if(len >=0) file_name[len]='\0';
	}

	if(output_path && _tcslen(output_path))
	{
		len=wide_char_to_utf8(output_dir , MAX_PATH-1, output_path , _tcslen(output_path));
		if(len >= 0) output_dir[_tcslen(output_path)]='\0';
	}
	
   // initialization with data in f_info if it exist 
   linkedList ll;
   int ret =ll.readFileInfo(nb_of_files, nb_of_record_in_file,nb_line_in_db, &pheader,keys);
   if(ret)
   {
	   struct Node*  tail=NULL;
	   int nb_read;
	   // load last file to memory
	   ll.readData(&llist,&tail,nb_read,nb_of_files);
	   //cout << "header " << header << endl;
   }
   
    //open input data files
    read.open(data_path);

    //Check if data file is open and reports
    if(!read.is_open())
	{
      perror(("error while opening file " + string(file_name)).c_str());
	  return 1;
	}
    
	//first line are column names
	std::getline (read,header_line);
	 
    //get and write data lines	
    while( std::getline (read,line))
	{
      nb_line_input++;
	  //cout << "Stream pointer currently in line " << nb_line_input << ".\n";
	  if(!line.empty())
	  {
		process(&llist,keys,line,nb_line_in_db);
		line.clear();
	  }
    }

    if (read.bad())
		perror(("error while reading file " + string(file_name)).c_str());
    //close the data files
    read.close();

	//printf("\n write nodes in linked List to file: \n");
	int nb_nodes_in_list ;
	int nb_of_last_file;
	if(nb_line_in_db%MAX_NB_LINE_IN_FILE ==0)
	{
		nb_nodes_in_list = MAX_NB_LINE_IN_FILE; // there are MAX_NB_LINE_IN_FILE nodes stil in memory, we should write then to disk
		nb_of_last_file = nb_line_in_db/MAX_NB_LINE_IN_FILE;
	}
	else
	{
		nb_nodes_in_list = nb_line_in_db%MAX_NB_LINE_IN_FILE;
		nb_of_last_file = nb_line_in_db/MAX_NB_LINE_IN_FILE  +1;
	}
	
	if(llist != NULL)
	{
		ll.writeData(llist,nb_nodes_in_list,nb_of_last_file);
		ll.clearupAllNodes(&llist);
	}

	cout << "nb_line_input = " << nb_line_input << ", nb_line_in_db = " << nb_line_in_db <<  ", keys.size = " << keys.size() << ", number of files =" << nb_of_last_file << ", max number of records in a file="<< MAX_NB_LINE_IN_FILE << endl <<endl;
	ll.writeFileInfo(nb_of_last_file, MAX_NB_LINE_IN_FILE, nb_line_in_db,header_line,keys);

	cout << "Get all nodes from db" << endl;
	struct Node*  head= NULL;
	ll.readNodesfromDB(&head,nb_line_in_db);
	cout << "\t\theader \t\t" << header_line << endl;
	ll.printList(head);
	ll.clearupAllNodes(&head);

	//getchar();

    return 0;
}

/*
bool have_same_keys(struct Node* node1, struct Node* node2)
{
	if((strcmp(node1->cms.stb, node2->cms.stb)==0) && (strcmp(node1->cms.title, node2->cms.title)==0) && (strcmp(node1->cms.date, node2->cms.date)==0) )
		return true;
	return false;
}
bool is_in_list(struct Node* list, struct Node* current_node)
{
	Node * node = list;
	while(node!=NULL)
	{
		if(have_same_keys(node,current_node))
			return true;
		else
			node = node->next;
	}
	return false;
}

bool is_in_file(struct Node* current_node, int nb_f)
{
	bool ret = false;
	struct Node* head = NULL;
	struct Node* tail = NULL;
	int nb_node = 0;

	linkedList ll;
	ll.readData(&head, &tail, nb_node, nb_f);
	if(is_in_list(head, current_node))
		ret = true;
	ll.clearupAllNodes(&head);
	return ret;
}

bool should_add(struct Node* list, struct Node* current_node, int nb_line)
{
	int nb_of_file = nb_line/MAX_NB_LINE_IN_FILE;
	
	if(is_in_list(list, current_node))
		return false;

	if(nb_line >=MAX_NB_LINE_IN_FILE )
	{
		if ((nb_line % MAX_NB_LINE_IN_FILE) ==0)
			--nb_of_file;   // have not dumped data to file yet, we are going to create a new file

		// TODO add hash check first
		for(int i=1; i <= nb_of_file; i++)
		{
			if(is_in_file(current_node,i))
				return false;
		}
	}
	return true;
}
*/

